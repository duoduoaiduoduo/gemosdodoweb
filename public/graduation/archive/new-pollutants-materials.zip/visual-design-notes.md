# 视觉版说明

2026-09-10。以 Apple 官方排版和布局规范为参考：系统字体、清楚的字号层级、分组留白、渐进披露、响应式布局与减少动态效果支持。不是 Apple 官方作品，也不声称完成其全部规范认证。

- https://developer.apple.com/design/human-interface-guidelines/typography
- https://developer.apple.com/design/human-interface-guidelines/layout

主页面采用概念主视觉、生活路径图、四类物质卡片、风险判断图、六节点时间轴及可筛选资料弹层。完整长文在 reference-guide.html 和 reference-china.html；原有数据集未删除。

主视觉：同目录 water-concept.png，使用内置 imagegen 生成。属于概念图，不是显微照片，不表示真实粒径、浓度或污染风险。已检查生成图；浏览器安全策略阻止本地页面自动预览，未完成新版屏幕验收。旧截图不代表新版。

## 生成提示词

Use case: stylized-concept. Asset type: landscape 3:2 educational website hero artwork, no UI. A single extremely elegant transparent water sphere, floating slightly above a calm dark navy water plane, subtle concentric ripple below it. Sphere centered, large, occupying central 65% of frame, delicate icy cyan refraction, fine silver highlights. Inside the sphere a few tiny abstract cyan and pale violet particles and filament-like traces to evoke the idea of unseen emerging contaminants; conceptual not a scientifically accurate microscopy image. Background seamless almost black midnight blue. Premium minimalist industrial design campaign, optical glass macro studio render, polished realism, art-directed dramatic lighting, sophisticated materials, tranquil and intriguing, not ominous. No text, no labels, no brands, no diagrams, no logos, no random decorative particles outside sphere. High resolution.
